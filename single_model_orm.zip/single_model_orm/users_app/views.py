from django.shortcuts import render, redirect
from .models import users

# Create your views here.
def index(request):
    context = {
        'all_users': users.objects.all()
    }
    return render(request, "index.html", context)

def create(request):
    users.objects.create(
        first_name= request.POST['f_name'], 
        last_name= request.POST['l_name'], 
        email_address= request.POST['email'], 
        age= request.POST['age'],
    )
    return redirect('/')